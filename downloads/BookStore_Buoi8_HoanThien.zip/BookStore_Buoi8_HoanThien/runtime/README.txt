Node.js v24.22.1 - Windows x64
Source: https://nodejs.org/dist/v24.22.1/win-x64/node.exe
Checksum reference: https://nodejs.org/dist/v24.22.1/SHASUMS256.txt
The bundled node.exe was compared against its SHA-256 entry (win-x64/node.exe).
License: NODE-LICENSE.txt (official Node.js v24.22.1 repository LICENSE).
The executable is included only in the ready-to-run Windows ZIP.
