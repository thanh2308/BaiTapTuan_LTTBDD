import { EmptyState } from "../components/EmptyState";
import React, { useState } from "react";
import { ScrollView, StyleSheet, Text } from "react-native";
import { FormField } from "../components/FormField";
import { PrimaryButton } from "../components/PrimaryButton";
import { updateProfile } from "../services/userService";
import { getErrorMessage } from "../api/client";
import { useAuth } from "../store/hooks";
import { showMessage } from "../utils/dialog";
import { validatePhone, validateRequired } from "../utils/validators";
import { RootScreenProps } from "../navigation/types";
import { colors } from "../theme";

// Bản rút gọn: chỉ sửa tên + SĐT (bỏ ảnh đại diện, đổi mật khẩu)
export function EditProfileScreen({
  navigation,
}: RootScreenProps<"EditProfile">) {
  const { user, patchUser } = useAuth();
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [touched, setTouched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const errors = {
    name: validateRequired("họ tên")(name),
    phone: validatePhone(phone),
  };

  const save = async () => {
    setTouched(true);
    if (errors.name || errors.phone || !user || loading) return;
    setLoading(true);
    setSubmitError(null);
    try {
      const updated = await updateProfile(user.id, {
        name: name.trim(),
        phone: phone.trim(),
      });
      patchUser(updated);
      showMessage("Đã lưu", "Thông tin hồ sơ đã được cập nhật.", () =>
        navigation.goBack(),
      );
    } catch (e) {
      setSubmitError(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };
  if (!user)
    return (
      <EmptyState
        emoji="🔒"
        title="Bạn cần đăng nhập"
        actionLabel="Đăng nhập"
        onAction={() => navigation.replace("Login")}
      />
    );

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    >
      <FormField
        label="Email (không thể đổi)"
        value={user.email}
        editable={false}
        style={{ opacity: 0.6 }}
      />
      <FormField
        label="Họ tên"
        value={name}
        onChangeText={setName}
        error={touched ? errors.name : null}
        autoCapitalize="words"
        editable={!loading}
      />
      <FormField
        label="Số điện thoại"
        value={phone}
        onChangeText={setPhone}
        error={touched ? errors.phone : null}
        keyboardType="phone-pad"
        editable={!loading}
      />
      {submitError ? <Text style={styles.error}>{submitError}</Text> : null}
      <PrimaryButton title="Lưu thay đổi" onPress={save} loading={loading} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 16, gap: 14 },
  error: { color: colors.danger, textAlign: "center" },
});
